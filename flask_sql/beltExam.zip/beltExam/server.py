from flask import Flask,render_template,redirect,request,session,flash
import re
from mysqlconnection import connectToMySQL
from flask_bcrypt import Bcrypt
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

from mysqlconnection import connectToMySQL

app = Flask(__name__)
bcrypt = Bcrypt(app)
app.secret_key = "IAmGroot!"

@app.route('/')
def index():
   return render_template ('index.html')

@app.route('/register', methods =['POST'])
def registerr():
    error = False
    if len(request.form['fname']) <2:
        flash("first Name mst be be more than 2 chsaracter")
    if len(request.form['lname']) <2:
        flash("last name canot be less than 2 ")
        error = True
    if len(request.form['password']) <8:
        flash('password must be 8 chracters')
        error = True
    if request.form['password']!=request.form['c_password']:
        flash("password should match")
        error= True
    if not request.form['fname'].isalpha():
        flash("No number is alowed in name")
        error = True
    if not request.form['lname'].isalpha():
        flash("No number is alowed in last name")
        error = True
    
    data = {
        "email" : request.form['email']
    }
    query = "SELECT * FROM users WHERE email = %(email)s"
    mysql = connectToMySQL('beltExam')
    matching_email_users = mysql.query_db(query,data)
    if len(matching_email_users) > 0:
        flash("Identity theft is not a joke")
        error = True
    if error:
        return redirect('/')

        
    data ={
        "first_name"   : request.form['fname'],
        "last_name"    : request.form['lname'],
        "email"        : request.form['email'],
        "password"     : request.form['password']
        }
    query = "insert into users (first_name,last_name,email,password,created_at, updated_at) values(%(first_name)s,%(last_name)s,%(email)s,%(password)s,now(),now())"
    mysql = connectToMySQL('beltExam')
    user_id=mysql.query_db(query,data )
    print(user_id)
    session['user_id'] = user_id

    return redirect('/')


@app.route('/login', methods=['POST'])
def login():
    data = {
        "email" : request.form['email']
    }
    query = "SELECT * FROM users WHERE email = %(email)s"
    mysql = connectToMySQL('beltexam')
    matching_email_users = mysql.query_db(query,data)
  
    if len(matching_email_users) == 0:
        flash("Invalid Credentials")
        print("bad email")
        return redirect('/')

    user = matching_email_users[0]
    print(user)
    if user['password'] != request.form['password']:
        flash("Invalid password")
        session['user_name'] = user['first_name']
        session['user_id'] = user['id']
        print(session['user_name'])
        return redirect('/')
    
    return redirect('/travels')

@app.route('/travels')
def travel():
    data ={}
    query ="select * from tripschedules"
    mysql = connectToMySQL('beltExam')
    trips=mysql.query_db(query)
    
    print(trips)
    return render_template("travels.html",trips=trips)


@app.route('/addtrip/<int:id>')
def addtrip(id):

    return render_template('addtrip.html',id=id)


@app.route('/process', methods=['POST'])
def process():
    data = {
        "des" : request.form['des'],
        "travel_start": request.form['startDate'],
        "travel_end": request.form['endDate'],
        "plan" : request.form['descrip'],
        "user_id": session['user_id']
    }
    query = "insert into tripschedules(destination,travel_start,travel_end,plan,created_at,updated_at,user_id) VALUES(%(des)s,%(travel_start)s,%(travel_end)s,%(plan)s,now(),now(),%(user_id)s)"
    mysql = connectToMySQL('beltExam')
    submitted_plan=mysql.query_db(query,data)
    print(submitted_plan)
    return redirect('/travels')

@app.route('/delete')
def delete():
    data ={
        "id": session['user_id']
    }
    query ="delete from tripschedules where id = %(id)s "
    mysql = connectToMySQL('beltExam')
    mysql.query_db(query,data)
    return redirect('/travels')
@app.route('/view')
def view():
    query ="select * from tripschedules"
    mysql = connectToMySQL('beltExam')
    viewresult=mysql.query_db(query)
    return render_template('view.html',viewresult=viewresult)



@app.route('/back')
def back():
    return redirect('/travels')
if __name__=='__main__':
    app.run(debug=True)